import os
import json
import aiohttp
from datetime import datetime, timedelta
from telegram import Update
from telegram.ext import (
    ApplicationBuilder,
    CommandHandler,
    ContextTypes,
    MessageHandler,
    filters
)

# ================== SETTINGS ==================
BOT_TOKEN = "BOT_TOKEN"

USAGE_FILE = "user_usage.json"
LOG_CHANNEL_USERNAME = "@xenolikelog"
ALLOWED_GROUP_ID = -1002834154228   # শুধুমাত্র এই গ্রুপে কাজ করবে
REQUIRED_CHANNEL = ""   # ব্যবহারকারীর অবশ্যই join করতে হবে

log_channel_id = None
MAX_FREE_USES_PER_DAY = 20
ADMIN_ID = 6262468884

CUSTOM_HEADERS = {
    # BUY @Samol_Hasan
}

user_usage = {}
LAST_ALLOWED_MESSAGE_IDS = set()   # Safe messages IDs

# ================== FILE SYSTEM ==================
def load_json_file(file_path, default):
    if os.path.exists(file_path):
        try:
            with open(file_path, "r") as f:
                return json.load(f)
        except json.JSONDecodeError:
            return default
    return default

def save_json_file(file_path, data):
    with open(file_path, "w") as f:
        json.dump(data, f)

def load_all_data():
    global user_usage
    user_usage = load_json_file(USAGE_FILE, {})

def save_all_data():
    save_json_file(USAGE_FILE, user_usage)

# ================== API REQUEST ==================
async def make_like_request(uid, region):
    try:
        params = {"uid": uid, "region": region}
        async with aiohttp.ClientSession() as session:
            async with session.get(
                "BUY @Samol_Hasan",
                params=params,
                headers=CUSTOM_HEADERS,
                timeout=15
            ) as response:
                if response.status == 200:
                    return await response.json()
                else:
                    return {"status": 0, "message": f"API Error: {response.status}"}
    except Exception as e:
        print(f"❌ Error: {e}")
        return {"status": 0, "message": "Network or API issue."}

# ================== HELPERS ==================
async def fetch_log_channel_id(bot):
    global log_channel_id
    chat = await bot.get_chat(LOG_CHANNEL_USERNAME)
    log_channel_id = chat.id
    print(f"✅ Log Channel ID fetched: {log_channel_id}")

async def is_user_in_channel(bot, user_id, channel_username):
    try:
        member = await bot.get_chat_member(channel_username, user_id)
        return member.status in ["member", "administrator", "creator"]
    except:
        return False

# ================== COMMANDS ==================
async def start_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    text = (
        "👋 Welcome to Free Fire Like Bot!\n\n"
        "Use this bot to send likes using your UID.\n\n"
        "📌 Commands:\n"
        "/like <uid> <region> — Send like (Group only)\n\n"
        f"Free Users: {MAX_FREE_USES_PER_DAY} likes every 24h\n"
        "Admin Users: Unlimited likes 🔥\n\n"
        f"⚠️ To use /like, you must join here: {REQUIRED_CHANNEL}"
    )
    msg = await update.message.reply_text(text)
    LAST_ALLOWED_MESSAGE_IDS.add(msg.message_id)

async def like_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    global log_channel_id
    chat = update.effective_chat
    user = update.effective_user
    chat_id = str(user.id)

    is_admin = user.id == ADMIN_ID

    # ==== JOIN CHECK ====
    #is_joined = await is_user_in_channel(context.bot, user.id, REQUIRED_CHANNEL)
    #if not is_joined:
    #    join_msg = await update.message.reply_text(
    #        f"❌ /like ব্যবহার করতে হলে আগে আমাদের চ্যানেলে join করুন:\n👉 [Join Channel]({REQUIRED_CHANNEL})",
    #        disable_web_page_preview=True
    #    )
    #    LAST_ALLOWED_MESSAGE_IDS.add(join_msg.message_id)
    #    return

    # ==== GROUP CHECK ====
    if chat.type == "private":
        private_msg = await update.message.reply_text(
            "❌ এই কমান্ড শুধুমাত্র গ্রুপে ব্যবহার করা যাবে। 👉 [Join Group](https://t.me/xenolikebot)",
            disable_web_page_preview=True
        )
        LAST_ALLOWED_MESSAGE_IDS.add(private_msg.message_id)
        return

    if chat.id != ALLOWED_GROUP_ID:
        group_msg = await update.message.reply_text(
            "❌ এই বট শুধুমাত্র নির্দিষ্ট গ্রুপে ব্যবহার করা যাবে। 👉 [Join Group](https://t.me/xenolikebot)",
            disable_web_page_preview=True
        )
        LAST_ALLOWED_MESSAGE_IDS.add(group_msg.message_id)
        return

    send = update.effective_message.reply_text
    now = datetime.utcnow()

    # ==== LIMIT CHECK ====
    if not is_admin:
        times = user_usage.get(chat_id, [])
        times = [t for t in times if now - datetime.fromisoformat(t) < timedelta(hours=24)]
        if len(times) >= MAX_FREE_USES_PER_DAY:
            limit_msg = await send(f"❌ আপনি ২৪ ঘণ্টায় {MAX_FREE_USES_PER_DAY} বারই ব্যবহার করতে পারবেন, প্রিমিয়াম কিনতে এডমিন কে মেসেজ করুন।")
            LAST_ALLOWED_MESSAGE_IDS.add(limit_msg.message_id)
            return
    else:
        times = user_usage.get(chat_id, [])

    # ==== ARGUMENT CHECK ====
    if len(context.args) != 2:
        usage_msg = await send("Usage: /like <uid> <region>")
        LAST_ALLOWED_MESSAGE_IDS.add(usage_msg.message_id)
        return

    uid = context.args[0]
    region = context.args[1].upper()

    processing_message = await send("⏳ লাইক পাঠানো হচ্ছে...")
    LAST_ALLOWED_MESSAGE_IDS.add(processing_message.message_id)

    # ==== API REQUEST ====
    data = await make_like_request(uid, region)

    if data and data.get("status") == 1:
        # শুধু SUCCESS হলে ক্রেডিট কাটবে
        if not is_admin:
            times.append(now.isoformat())
            user_usage[chat_id] = times
            save_all_data()

        player = data.get("player", {})
        likes = data.get("likes", {})

        # credits calculation
        if not is_admin:
            used_today = len(times)
            credits_left = max(0, MAX_FREE_USES_PER_DAY - used_today)
        else:
            credits_left = "∞"

        msg_text = (
            f"✅ Like Added Successfully!\n"
            f"👤 {player.get('nickname', 'N/A')}\n"
            f"🆔 {player.get('uid', 'N/A')}\n"
            f"👍 Before: {likes.get('before', 'N/A')}\n"
            f"➕ Added: {likes.get('added_by_api', 'N/A')}\n"
            f"❤️ Total: {likes.get('after', 'N/A')}\n\n"
            f"📊 Remaining Requests Today: {credits_left}\n\n"
            f"👤 Requested by: {user.first_name}\n\n"
             f"💡 Upgrade to VIP for unlimited requests!"
        )

        # 🔽 ইউজারের টেলিগ্রাম প্রোফাইল ছবি পাঠানো
        try:
            photos = await context.bot.get_user_profile_photos(user.id, limit=1)
            if photos.total_count > 0:
                file_id = photos.photos[0][-1].file_id
                await processing_message.delete()
                final_msg = await update.message.reply_photo(
                    photo=file_id,
                    caption=msg_text
                )
            else:
                final_msg = await processing_message.edit_text(msg_text)
        except Exception as e:
            print(f"⚠️ Failed to load profile photo: {e}")
            final_msg = await processing_message.edit_text(msg_text)

        LAST_ALLOWED_MESSAGE_IDS.add(final_msg.message_id)

        if log_channel_id:
            await context.bot.send_message(
                chat_id=log_channel_id,
                text=(
                    f"📢 Like Processed!\n"
                    f"User: {user.username or user.id}\n"
                    f"UID: {player.get('uid')}\n"
                    f"Likes: {likes.get('after')} (+{likes.get('added_by_api')})"
                )
            )
    else:
        # ❌ Error বা Already Liked হলে ক্রেডিট কমবে না
        player = data.get("player", {}) if data else {}
        fail_msg = await processing_message.edit_text(
            f"⚠️ ACCOUNT ALREADY LIKED ! ⚠️\n\n"
            f"👤 {player.get('nickname', 'N/A')}\n"
            f"🆔 {player.get('uid', uid)}"
        )
        LAST_ALLOWED_MESSAGE_IDS.add(fail_msg.message_id)

async def about_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    count = len(user_usage)
    msg = await update.message.reply_text(f"📊 Free users used (24h): {count}")
    LAST_ALLOWED_MESSAGE_IDS.add(msg.message_id)

async def broadcast_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if update.effective_user.id != ADMIN_ID:
        deny_msg = await update.message.reply_text("❌ Only admin can use this command.")
        LAST_ALLOWED_MESSAGE_IDS.add(deny_msg.message_id)
        return

    if not context.args:
        usage_msg = await update.message.reply_text("Usage: /broadcast <message>")
        LAST_ALLOWED_MESSAGE_IDS.add(usage_msg.message_id)
        return

    msg = "📢 Broadcast:\n" + " ".join(context.args)
    success = fail = 0

    for uid in user_usage.keys():
        try:
            await context.bot.send_message(chat_id=int(uid), text=msg)
            success += 1
        except:
            fail += 1

    report_msg = await update.message.reply_text(f"✅ Sent: {success} | ❌ Failed: {fail}")
    LAST_ALLOWED_MESSAGE_IDS.add(report_msg.message_id)

# ================== AUTO DELETE HANDLER ==================
async def auto_delete(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if update.effective_chat.type != "private":
        if update.effective_user and update.effective_user.id == context.bot.id:
            if update.message.message_id not in LAST_ALLOWED_MESSAGE_IDS:
                try:
                    await update.message.delete()
                except:
                    pass

# ================== STARTUP ==================
async def on_startup(app):
    load_all_data()
    await fetch_log_channel_id(app.bot)
    print("Bot Ready!")

if __name__ == "__main__":
    app = ApplicationBuilder().token(BOT_TOKEN).post_init(on_startup).build()

    app.add_handler(CommandHandler("start", start_command))
    app.add_handler(CommandHandler("like", like_command))
    app.add_handler(CommandHandler("about", about_command))
    app.add_handler(CommandHandler("broadcast", broadcast_command))

    # Auto delete সব message filter করবে
    app.add_handler(MessageHandler(filters.ALL, auto_delete))

    print("🚀 Bot Running...")
    app.run_polling()
